<?php
/**
 * @package WordPress
 * @subpackage Ecommerce
 */

get_header();?>

    <nav id="breadcrumbs">
        <a href="<?php url_site()?>" title="<?php trans('Back to Home page','Voltar para a página inicial')?>">Home</a> 
        &nbsp;<img src="<?php url_tema('img/seta.png')?>">&nbsp;
        <?php 
        if($wp_query->queried_object->parent){
            echo get_term_parents($wp_query->queried_object->parent,'categoria',true,'-',false);   
        }
        ?>
    </nav>
    
    <h1><?php single_cat_title()?></h1>
    
    <?php if(have_posts()): $cont = 0;?>
    <ul class="lista horizontal">
    
        <?php while(have_posts()): the_post(); $cont++; ?>
        <li <?php if($cont == 4){echo 'class="last"'; $cont = 0;}?>>
            <?php if(has_post_thumbnail()){ 
            $idattach = get_post_thumbnail_id($post->ID);
            $full = wp_get_attachment_image_src($idattach,'full');
            $medio = wp_get_attachment_image_src($idattach,'medio');
			$novidade = get_post_meta($post->ID, 'pr_novidade', TRUE);
            ?>
                <a title="<?php the_title()?>" href="<?php the_permalink()?>">
                    <img src="<?php echo $medio[0];?>">
					<?php if($novidade){?>
						<img class="novidade" src="<?php url_tema(trans('img/novidade-en.png','img/novidade.png',false))?>">
					<?php }?>
                </a>
            <?php } ?>
            
            <a href="<?php the_permalink()?>"><?php the_title()?></a>
            <p><?php if(is_en()){echo get_post_meta($post->ID, 'en_resumo', TRUE);}else{echo get_post_meta($post->ID, 'pt_resumo', TRUE);}?></p>
			<a title="<?php the_title()?>" href="<?php the_permalink()?>" class="saiba-mais"><?php trans('more details','ver produto')?></a>
        </li>
        <?php endwhile; ?>
        
    </ul>
    <?php endif;?>
    
<?php get_footer(); ?>