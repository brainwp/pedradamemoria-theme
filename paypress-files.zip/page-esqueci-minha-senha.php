<?php
/**
 * @package WordPress
 * @subpackage Ecommerce
 */
if(!empty($_POST['email']) && wp_verify_nonce(esc_attr($_POST['logar']), 'produto-nonce') && is_email(esc_attr($_POST['email']))){
	global $erro;
	$input_ok = true;
	
	$email = esc_attr($_POST['email']);
	$lang = esc_attr($_POST['lang']);
	
	if(email_exists($email)){
		$user_id = email_exists($email);
		$senha = wp_generate_password(6, false);
		
		wp_update_user(array('ID'=> $user_id, 'user_pass' => $senha));
		
		$headers = 'Reply-To: info@ecommerce.com \r\n';
		if($lang == 'pt'){ 
			$subject = "Esqueci minha senha"; 
			$msg.= "<h1>Alteração de senha de acesso</h1>";
			$msg.= "<p>Aqui está sua nova senha: {$senha}</p>";
			$msg.= "<p>Para visualizar o status de seus pedidos, acesse <a href='http://ecommerce.com.br/".$lang."/pedidos'>este link</a></p>";
			$msg.= "<br>";
			$msg.= "<p>Em caso de dúvida, entre em contato conosco respondendo a esta mensagem.</p>";
		}
		if($lang == 'en'){ 
			$subject = "Forgot my password"; 
			$msg.= "<h1>Change password</h1>";
			$msg.= "<p>Here is your new password: {$senha}</p>";
			$msg.= "<p>To monitor the status of your orders, use <a href='http://ecommerce.com.br/".$lang."/pedidos'>this link</a></p>";
			$msg.= "<br>";
			$msg.= "<p>If in doubt please contact us replying to this email.</p>";
		}
		wp_mail($email, $subject, $msg, $headers );
		alert('Verifique sua conta de email para ver sua nova senha');
	}else{$erro = "Erro: Não existe nenhuma conta registrada com este e-mail";}
	
}

get_header(); 

	if(have_posts()): while(have_posts()): the_post();?>
    
    <nav id="breadcrumbs">
        <a href="<?php url_site()?>" title="Voltar para a página inicial">Home</a>
        &nbsp;<img src="<?php url_tema('img/seta.png')?>">&nbsp;
        <?php 
        if($post->post_parent){
            $pai = get_post($post->post_parent);
            //printr($pai);
            ?>
            <a href="<?php url_site($pai->post_name)?>"><?php echo $pai->post_title;?></a>
            <?php
        }
        ?>
    </nav>
        
    <h1><?php the_title()?></h1>
    
    <article id="page">
	<?php the_content()?>
    <?php if(is_user_logged_in()): 
    global $current_user;
    get_currentuserinfo();  
    //printr($current_user);
    ?>
        <p>Logado como: 
        <?php echo $current_user->user_email; ?> - <a href="<?php echo wp_logout_url(get_permalink()); ?>">sair</a>
        </p>
                
        <p><a href="<?php url_site('pedidos') ?>">
            Acessar meus pedidos
        </a></p>
        
    <?php else : ?>
        
        <form action="" method="post">
			<?php wp_nonce_field('produto-nonce','logar'); ?>
			<input type="hidden" name="lang" value="<?php echo qtrans_getLanguage();?>">
            <label for="email">E-mail</label>
            <input tabindex="1" type="text" name="email" id="email" value="<?php echo $_POST['log']?>">
            
            <input tabindex="3" type="image" src="<?php url_tema('img/entrar.png')?>">
            
            <?php if(!empty($erro)){?>
                <p><br><div class="warning"><?php echo $erro;?></div></p>
            <?php }?>
        </form>

    <?php endif; ?>
    </article>
        
	<?php endwhile; endif;?>
    
<?php get_footer() ?>