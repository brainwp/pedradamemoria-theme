<?php
/**
 * @package WordPress
 * @subpackage Ecommerce
 */
if(!empty($_POST['logar']) && wp_verify_nonce(esc_attr($_POST['logar']), 'produto-nonce') && is_email(esc_sql($_POST['log'])) && !empty($_POST['pwd'])){
	global $erro;
	$input_ok = true;
	
	$email = esc_sql($_POST['log']);
	$password = esc_sql($_POST['pwd']);
	$remember = esc_sql($_POST['rememberme']);
	$ref = esc_sql($_POST['ref']);
	
	if(email_exists($email)){
		if(empty($password)){ $erro = "Erro: Você deve digitar uma senha!"; $input_ok = false;}
	}else{$erro = "Erro: Não existe nenhuma conta registrada com este e-mail"; $input_ok = false;}
	
	if($input_ok){
		($remember) ? true : false;
		$login_data = array();
		$login_data['user_login'] = $email;
		$login_data['user_password'] = $password;
		$login_data['remember'] = $remember;
		$user_verify = wp_signon( $login_data, false ); 
		
		if ( is_wp_error($user_verify) ){
			//$erro = $user_verify->get_error_message();
			$erro = "Erro: Senha incorreta!"; 
		} else {	
			if(!empty($ref) && $ref == 'finalizar'){
				wp_redirect(get_bloginfo('url').'/finalizar-compra/');
			}else{
				wp_redirect(get_bloginfo('url').'/pedidos/');
			}
			exit();
			//global $current_user;
			//get_currentuserinfo(); 
		}
	}
}

get_header(); 

	if(have_posts()): while(have_posts()): the_post();?>
    
    <nav id="breadcrumbs">
        <a href="<?php url_site()?>" title="Voltar para a página inicial">Home</a>
        &nbsp;<img src="<?php url_tema('img/seta.png')?>">&nbsp;
        <?php 
        if($post->post_parent){
            $pai = get_post($post->post_parent);
            //printr($pai);
            ?>
            <a href="<?php url_site($pai->post_name)?>"><?php echo $pai->post_title;?></a>
            <?php
        }
        ?>
    </nav>
        
    <h1><?php the_title()?></h1>
    
    <article id="page">
    <?php if(is_user_logged_in()): 
    global $current_user;
    get_currentuserinfo();  
    //printr($current_user);
    ?>
        <p>Logado como:
        <?php echo $current_user->user_email; ?> - <a href="<?php echo wp_logout_url(get_permalink()); ?>"><?php trans('logout','sair')?></a>
        </p>
                
        <p><a href="<?php url_site('pedidos') ?>">
            Acessar meus pedidos
        </a></p>
        
    <?php else : ?>
        
        <form action="" method="post">
			<?php wp_nonce_field('produto-nonce','logar'); ?>
            <label for="log">E-mail</label>
            <input tabindex="1" type="text" name="log" id="log" value="<?php echo $_POST['log']?>">
            
            <label for="pwd">Senha</label>
            <input tabindex="2" name="pwd" id="pwd" type="password" value="<?php echo $_POST['pwd']?>">
            
            <input type="hidden" name="rememberme" value="true" />
			<input type="hidden" name="ref" value="<?php echo $_GET['ref']?>">
            <input tabindex="3" type="image" src="<?php url_tema('img/entrar.png')?>">
            <p><br><a href="<?php url_site('esqueci-minha-senha') ?>">Esqueceu a sua senha?</a></p>
            <?php if(!empty($erro)){?>
                <p><br><div class="warning"><?php echo $erro;?></div></p>
            <?php }?>
        </form>

    <?php endif; ?>
    </article>
        
	<?php endwhile; endif;?>
    
<?php get_footer() ?>