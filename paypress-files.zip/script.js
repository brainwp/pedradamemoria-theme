(function($){
	
	$(document).ready(function(){

		$("#menu div").hover(
		  function () {
			$(this).addClass("menu-open");
			$(this).children("ul").css('display' , 'block');
		  }, 
		  function () {
			$(this).removeClass("menu-open");  
			$(this).children("ul").css('display' , 'none');
		  }
		);
		
		$("#thumbnails a").click(function(e){
			//$("#produto-img .cboxElement").fadeIn("slow").html("<img src='"+ this.href +"'>");
			$("#produto-img .cboxElement img").attr("src",this.href).hide().fadeIn("slow");
			$("#produto-img .cboxElement").attr("href",this.title);
			return false;
		});
		
		$("#cores-disponiveis li a").live('click',function() {
			$("#cores-disponiveis li").removeClass("ativo");
			$(this).parent().addClass("ativo");
			$("#tamanhos-disponiveis ul").addClass("fechado");
			$("#"+this.title).removeClass("fechado");
			/*
			$("#"+this.title+' li a').removeClass("ativo");
			$("#"+this.title+' li a:first').addClass("ativo");
			*/
			$("#pr-cor").attr("value",this.title);
			/*	
			$("#pr-tamanho").attr("value",$("#"+this.title+' li a:first').attr("title"));	
			$("#pr-qntd").attr("value",$("#"+this.title+' li a:first').attr("data-qntd"));	
			$("#pr-rand").attr("value",$("#"+this.title+' li a:first').attr("data-rand"));
			*/
		});
		
		$("#tamanhos-disponiveis li a").live('click',function() {
			$("#tamanhos-disponiveis li a").removeClass("ativo");
			$(this).addClass("ativo");
			$("#pr-cor").attr("value",$("#cores-disponiveis li.ativo a").attr("title"));	
			$("#pr-tamanho").attr("value",$(this).attr("title"));	
			$("#pr-qntdmax").attr("value",$(this).attr("data-qntdmax"));	
			$("#pr-rand").attr("value",$(this).attr("data-rand"));	
		});
		
		$("#pr-form").submit(function(e){
			var tamanho = $("#pr-tamanho").val(); 
			var cor = $("#pr-cor").val();
			if(cor === ""){
				alert('Você deve escolher uma cor!');
				 e.preventDefault();
			}
			else if(tamanho === ""){
				alert('Você deve escolher um tamanho!');
				 e.preventDefault();				
			}
			else {
				//return true;
				$(this).submit();
			}
		});
		
		$(".carrinho-remover a").live('click',function(){
			$(this).parent().submit();
		});
		
		$('#formas-envio input[type="radio"]').change(function(){
			$("#tipo_frete").attr("value",$(this).attr("data-tipofrete"));
			$("#item_frete_1").attr("value",$(this).val());
			
			$("#total-frete").html('R$ '+$(this).attr("data-preco"));
			$("#total-frete").attr("data-valor",$(this).attr("data-valor"));
			var subtotal = $("#total").attr("data-valor");
			var frete = $("#total-frete").attr("data-valor");
			var soma = parseFloat(subtotal) + parseFloat(frete);
			$("#total-geral").html(soma.toFixed(2)).formatCurrency({ region: 'pt-BR' });
			$("#finalizar-compra").css("display","block");
		});	
		
		$('#pr-cep').keypress(function(e){
			if(e.which == 13){
		   		$(this).parent().submit();
		   	}
		});
		
	});

})(window.jQuery);

function MM_formtCep(e,src,mask) {
	if(window.event) { _TXT = e.keyCode; } 
	else if(e.which) { _TXT = e.which; }
	if(_TXT > 47 && _TXT < 58) { 
		var i = src.value.length; 
		var saida = mask.substring(0,1); 
		var texto = mask.substring(i)
		if(texto.substring(0,1) != saida) { src.value += texto.substring(0,1); } 
		return true; 
	} 
	else{ 
		if (_TXT != 8) { return false; } 
		else { return true; }
	}
}