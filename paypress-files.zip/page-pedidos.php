<?php
/**
 * @package WordPress
 * @subpackage Ecommerce
 */

get_header(); 

if(have_posts()): while(have_posts()): the_post();?>

	<nav id="breadcrumbs">
		<a href="<?php url_site()?>" title="Voltar para a página inicial">Home</a>
		&nbsp;<img src="<?php url_tema('img/seta.png')?>">&nbsp;
		<?php 
		if($post->post_parent){
			$pai = get_post($post->post_parent);
			//printr($pai);
			?>
			<a href="<?php url_site($pai->post_name)?>"><?php echo $pai->post_title;?></a>
			<?php
		}
		?>
	</nav>
		
	<h1><?php the_title()?></h1>
<?php endwhile; endif;?>    
	
<article id="page">
<?php if(is_user_logged_in()){
	
	global $current_user; 
	get_currentuserinfo();
	
	$user_id = $current_user->ID;
	$email = $current_user->user_email;
	
	$l1 = new WP_Query(array('posts_per_page' => '-1', 'post_type'=> 'pedido', 'meta_key'=> 'id_usuario_wp', 'meta_value'=> $user_id , 'tax_query' => array(array('taxonomy' => 'status','terms' => array('registro'),'field' => 'slug','operator' => 'NOT IN')))); 
	if($l1->have_posts()){ while($l1->have_posts()): $l1->the_post(); 
	
	$produtos = get_post_meta($post->ID, 'produtos',TRUE);
	
	$pedido_data = get_the_date('d/m/Y G:i:s');
	$forma_pagamento = get_post_meta($post->ID, 'forma_pagamento',TRUE);
	
	$valor_frete = get_post_meta($post->ID, 'valor_frete',TRUE);
	$valor_pedido = get_post_meta($post->ID, 'valor_pedido',TRUE);
	$valor_itens = get_post_meta($post->ID, 'valor_itens',TRUE);
	
	$frete_escolhido = strtoupper(get_post_meta($post->ID, 'frete_escolhido',TRUE));
	$tipo_frete = get_post_meta($pedido_id, 'tipo_frete', TRUE);
	
	if($frete_escolhido == 'EMS'){$frete_escolhido = 'Mercadoria Expressa (EMS)';}
	if($frete_escolhido == 'LEVE'){$frete_escolhido = 'Leve Prioritário';}
			
	$tracking = get_post_meta($post->ID, 'tracking',TRUE);
	
	//if(strtoupper($frete_escolhido) == 'PAC'){$valor_frete = 0;}
	
	$nome = get_post_meta($post->ID, 'nome',TRUE);
	$email = get_post_meta($post->ID, 'email',TRUE);
	$ddd = get_post_meta($post->ID, 'ddd',TRUE);
	$telefone = get_post_meta($post->ID, 'telefone',TRUE);
	
	$cep = get_post_meta($post->ID, 'cep',TRUE);
	$endereco = get_post_meta($post->ID, 'endereco',TRUE);
	$numero = get_post_meta($post->ID, 'numero',TRUE);
	$complemento = get_post_meta($post->ID, 'complemento',TRUE);
	$bairro = get_post_meta($post->ID, 'bairro',TRUE);
	$estado = get_post_meta($post->ID, 'estado',TRUE);
	$cidade = get_post_meta($post->ID, 'cidade',TRUE);
	$outra_cidade = get_post_meta($post->ID, 'outra_cidade',TRUE);
	$pais = get_post_meta($post->ID, 'pais',TRUE);
	$pais_nome = get_post_meta($post->ID, 'pais_nome',TRUE);
	?>

		<table class="pedidos">
			<thead>
				<tr>
					<th>Pedido número: <?php echo $post->ID;?></th>
					<th>Itens</th>
				</tr>
			</thead>
			<tbody>
				<tr>
					<td width="400">
						<table class="pedidos-dados">
							<tr><th><?php trans('Order date','Data do pedido')?>:</th><td><?php echo $pedido_data;?></td></tr>
							<tr><th><?php trans('Payment Method','Sistema de Pagamento')?>:</th><td><img src="<?php url_tema('img/forma-'.$forma_pagamento.'.png?v=1')?>"></td></tr>
							<tr>
								<th><?php trans('Current status','Status atual')?>:</th>
								<td>
									<?php
									$categorias = get_the_terms($post->ID, "status");
									if(!empty($categorias)){
										$categorias_html = array();
										foreach ($categorias as $categoria)
											//array_push($categorias_html, '<a href="' . get_term_link($categoria->slug, "status") . '">' . $categoria->name . '</a>');
											array_push($categorias_html, $categoria->name);				
										echo implode($categorias_html, ", ");
									}
									?>
								</td>
							</tr>
							
							<tr><th><?php trans('Shipping Method','Frete escolhido')?>:</th><td><?php echo $frete_escolhido;?></td></tr>
							<?php if($tipo_frete == 'brasil'){?>
							<tr><th><?php trans('Tracking Code','Código de Rastreamento')?>:</th><td><?php echo $tracking;?></td></tr>
							<?php } ?>
							<tr><th><?php trans('Name','Nome')?>:</th><td><?php echo $nome;?></td></tr>
							<tr><th><?php trans('E-mail','E-mail')?>:</th><td><?php echo $email;?></td></tr>
							<tr><th><?php trans('Phone number','Telefone')?>:</th><td>(<?php echo $ddd;?>) <?php echo $telefone;?></td></tr>

							
							<tr><th><?php trans('Postal Code','CEP')?>:</th><td><?php echo $cep;?></td></tr>
							<tr><th><?php trans('Address','Endereço')?>:</th><td><?php echo $endereco;?></td></tr>
							<tr><th><?php trans('Number','Número')?>:</th><td><?php echo $numero;?></td></tr>
							<tr><th><?php trans('Complement','Complemento')?>:</th><td><?php echo $complemento;?></td></tr>
							<tr><th><?php trans('District','Bairro')?>:</th><td><?php echo $bairro;?></td></tr>
							<tr><th><?php trans('City','Cidade')?>:</th><td><?php if(empty($cidade)){ echo $outra_cidade;}else{ echo $cidade;} ?></td></tr>
							<tr><th><?php trans('State','Estado')?>:</th><td><?php echo $estado;?></td></tr>
							<tr><th><?php trans('Country','País')?>:</th><td><?php echo $pais_nome.' ('.$pais.')';?></td></tr>
						</table>
					</td>
					<td>
						<table class="pedidos-itens">
							<thead>
								<tr>
									<th><?php trans('product','produto')?></th>
									<th><?php trans('colour','cor')?></th>
									<th><?php trans('size','tamanho')?></th>
									<th><?php trans('price','preço')?></th>
									<th><?php trans('quantity','quantidade')?></th>
									<th><?php trans('total price','valor total')?></th>
								</tr>
							</thead>
							<tbody>
								<?php foreach ($produtos as $key => $item){ $prod = get_post($item['id']);?>
								<tr>
									<td>
										<?php if(has_post_thumbnail($prod->ID)){ 
											$idattach = get_post_thumbnail_id($prod->ID);
											$full = wp_get_attachment_image_src($idattach,'full');
											$large = wp_get_attachment_image_src($idattach,'large');
											$thumb = wp_get_attachment_image_src($idattach,'thumbnail');
											$mini = wp_get_attachment_image_src($idattach,'mini');
											?>
												<img src="<?php echo $mini[0];?>">
										<?php } ?>   
										<br>
										<a href="<?php echo url_site($prod->post_name);?>"><?php _e($prod->post_title);?></a>
									</td>
									<td><?php echo $item['cor']?></td>
									<td><?php echo $item['tamanho']?></td>
									<td>R$ <?php echo number_format($item['valor'], 2, ',', '.');?></td>
									<td><?php echo $item['quantidade']?></td>
									<td><b>R$ <?php echo number_format($item['valortotal'], 2, ',', '.');?></b></td>
								</tr>
								<?php } //end for ?>
							</tbody>
							<tfoot>
								<tr><th colspan="5">Subtotal</th><td>R$ <?php echo number_format($valor_itens, 2, ',', '.');?></td></tr>
								<tr><th colspan="5"><?php trans('Shipping','Frete')?></th><td>R$ <?php echo number_format($valor_frete, 2, ',', '.');?></td></tr>
								<tr><th colspan="5">Total</th><td>R$ <?php echo number_format($valor_pedido, 2, ',', '.');?></td></tr>
							</tfoot>
						</table>
					</td>
				</tr>
			</tbody>
			<tfoot>
				<tr><td colspan="2"><hr class="hr940-table"></tr>
			</tfoot>
		</table>
			
	<?php endwhile; }else{?>
		
		<h6><?php trans('No orders found in your account!','Não existem pedidos na sua conta!')?></h6>
		
		<hr class="hr940">
		
		<h6><?php trans('Discover our products','Conheça os produtos da Ecommerce')?></h6>
		
		<?php
		$cont = 0;
		$produtos = new WP_Query(array('posts_per_page' => '-1','post_type'=> 'produto','meta_key'=> 'destaque', 'meta_value'=>'on')); 
		if($produtos->have_posts()): ?>
		<ul class="lista horizontal">
		
			<?php while($produtos->have_posts()): $produtos->the_post(); $cont++; ?>
			<li <?php if($cont == 4){echo 'class="last"'; $cont = 0;}?>>
				<?php if(has_post_thumbnail()){ 
				$idattach = get_post_thumbnail_id($post->ID);
				$full = wp_get_attachment_image_src($idattach,'full');
				$medio = wp_get_attachment_image_src($idattach,'medio');
				$novidade = get_post_meta($post->ID, 'pr_novidade', TRUE);
				?>
					<a title="<?php the_title()?>" href="<?php the_permalink()?>">
						<img src="<?php echo $medio[0];?>">
						<?php if($novidade){?>
							<img class="novidade" src="<?php url_tema(trans('img/novidade-en.png','img/novidade.png',false))?>">
						<?php }?>
					</a>
				<?php } ?>
				
				<a href="<?php the_permalink()?>"><?php the_title()?></a>
				<p><?php if(is_en()){echo get_post_meta($post->ID, 'en_resumo', TRUE);}else{echo get_post_meta($post->ID, 'pt_resumo', TRUE);}?></p>
			</li>
			<?php endwhile; ?>
			
		</ul>
		<?php endif;?>	
		
	<?php }?>

<?php }else{ ?>

	<h6><?php trans('You must be logged in to view this page!','Você deve estar logado para ver esta página!')?></h6>
	
	<p><a href="<?php url_site('login')?>">Login</a></p>
	
	<hr class="hr940">
		
	<h6><?php trans('Discover our products','Conheça os produtos da Ecommerce')?></h6>
	
	<?php
	$cont = 0;
	$produtos = new WP_Query(array('posts_per_page' => '-1','post_type'=> 'produto','meta_key'=> 'destaque', 'meta_value'=>'on')); 
	if($produtos->have_posts()): ?>
	<ul class="lista horizontal">
	
		<?php while($produtos->have_posts()): $produtos->the_post(); $cont++; ?>
		<li <?php if($cont == 4){echo 'class="last"'; $cont = 0;}?>>
			<?php if(has_post_thumbnail()){ 
			$idattach = get_post_thumbnail_id($post->ID);
			$full = wp_get_attachment_image_src($idattach,'full');
			$medio = wp_get_attachment_image_src($idattach,'medio');
			$novidade = get_post_meta($post->ID, 'pr_novidade', TRUE);
			?>
				<a title="<?php the_title()?>" href="<?php the_permalink()?>">
					<img src="<?php echo $medio[0];?>">
					<?php if($novidade){?>
						<img class="novidade" src="<?php url_tema(trans('img/novidade-en.png','img/novidade.png',false))?>">
					<?php }?>
				</a>
			<?php } ?>
			
			<a href="<?php the_permalink()?>"><?php the_title()?></a>
			<p><?php if(is_en()){echo get_post_meta($post->ID, 'en_resumo', TRUE);}else{echo get_post_meta($post->ID, 'pt_resumo', TRUE);}?></p>
		</li>
		<?php endwhile; ?>
		
	</ul>
	<?php endif;?>	
	
<?php }?>			
</article>    
    
<?php get_footer() ?>