(function($){
	$(document).ready(function(){
		
		
		
		
		
	});
})(window.jQuery);