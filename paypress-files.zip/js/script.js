(function($){
	$(document).ready(function(){
			
		// PRODUTO ------------------------------------------------------
		$("#thumbnails a").click(function(e){
			//$("#produto-img .cboxElement").fadeIn("slow").html("<img src='"+ this.href +"'>");
			$("#produto-img .cboxElement img").attr("src",this.href).hide().fadeIn("slow");
			$("#produto-img .cboxElement").attr("href",this.title);
			return false;
		});
		
		$("#cores-disponiveis li a").live('click',function() {
			$("#cores-disponiveis li").removeClass("ativo");
			$(this).parent().addClass("ativo");
			$("#tamanhos-disponiveis ul").addClass("fechado");
			$cor = $(this).attr("data-cor");
			$("#"+$cor).removeClass("fechado");
			/*
			$("#"+this.title+' li a').removeClass("ativo");
			$("#"+this.title+' li a:first').addClass("ativo");
			*/
			$("#pr-cor").attr("value",$(this).attr("data-nomecor"));	
			$("#pr-tamanho").attr("value","");	
			$("#pr-qntdmax").attr("value","");	
			$("#pr-rand").attr("value","");
			$("#tamanhos-disponiveis li a").removeClass("ativo");
		});
		
		$("#tamanhos-disponiveis li a").live('click',function() {
			$("#tamanhos-disponiveis li a").removeClass("ativo");
			$(this).addClass("ativo");
			$("#pr-cor").attr("value",$("#cores-disponiveis li.ativo a").attr("data-nomecor"));	
			$("#pr-tamanho").attr("value",$(this).attr("data-tamanho"));	
			$("#pr-qntdmax").attr("value",$(this).attr("data-qntdmax"));	
			$("#pr-rand").attr("value",$(this).attr("data-rand"));	
		});
		
		// CARRINHO ------------------------------------------------------
		$(".carrinho-remover a").live('click',function(){
			$(this).parent().submit();
		});
		
		$('#formas-envio input[type="radio"]').change(function(){
			var $radio = $(this);
			$("#co-frete-tipo").attr("value",$radio.attr("data-frete-tipo"));
			
			$("#total-frete").html('R$ '+$radio.attr("data-preco"));
			$("#total-frete").attr("data-valor",$radio.attr("data-valor"));
			
			var subtotal = $("#subtotal").attr("data-valor");
			var frete = $("#total-frete").attr("data-valor");
			var soma = parseFloat(subtotal) + parseFloat(frete);
			
			$("#total-geral").html(soma.toFixed(2)).formatCurrency({ region: 'pt-BR' });
			$("#finalizar-compra").fadeIn("slow");
		});	
		
		$('#pr-cep').keypress(function(e){
			if(e.which == 13){
		   		$(this).parent().submit();
		   	}
		});
		
		$("#pr-cep").mask("99999-999");
		
		// FINALIZAR COMPRA -----------------------------------------------
		$(".outra_cidade").on("click",function(){
			
			$("#outra_cidade").fadeToggle("slow", function(){
				if($("#cidade").prop("disabled")){
					$("#cidade").prop("disabled",false);
					$("#cidade").attr("required",true);
					$("#cidade").fadeIn();
					$("#outra_cidade").hide();
					$("#outra_cidade").prop("disabled",true);
					$("#outra_cidade").attr("required",false);
					$("#cidade").focus();
					$(".outra_cidade").removeClass("up");
					$(".outra_cidade").addClass("down");
				}else{
					$("#outra_cidade").prop("disabled",false);
					$("#outra_cidade").attr("required",true);
					$("#outra_cidade").fadeIn("fast");
					$("#cidade").hide();
					$("#cidade").prop("disabled",true);
					$("#cidade").attr("required",false);
					$(".outra_cidade").removeClass("down");
					$(".outra_cidade").addClass("up");
				}
			});
			return false;
		});
		
		$("#checkout input[type=image]").blur(function(){
			$("#nome").focus();
		});
				
	});
})(window.jQuery);