<?php
/**
 * @package WordPress
 * @subpackage Ecommerce
 */

get_header(); 

	if(have_posts()): while(have_posts()): the_post();?>
    
        <nav id="breadcrumbs">
            <a href="<?php url_site()?>" title="Voltar para a página inicial">Home</a>
			&nbsp;<img src="<?php url_tema('img/seta.png')?>">&nbsp;
            <?php 
			if($post->post_parent){
				$pai = get_post($post->post_parent);
				//printr($pai);
				?>
                <a href="<?php url_site($pai->post_name)?>"><?php echo $pai->post_title;?></a>
                <?php
			}
			?>
        </nav>
			
        <h1><?php the_title()?></h1>
        
        <article id="page">
			<?php the_content();?>
        </article>
		
	<?php endwhile; endif;?>
	
<?php get_footer() ?>