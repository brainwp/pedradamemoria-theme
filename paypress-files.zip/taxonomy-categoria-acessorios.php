<?php
/**
 * @package WordPress
 * @subpackage Ecommerce
 */

get_header();?>

    <nav id="breadcrumbs">
        <a href="<?php url_site()?>" title="<?php trans('Back to Home page','Voltar para a página inicial')?>">Home</a> 
        &nbsp;<img src="<?php url_tema('img/seta.png')?>">&nbsp;
        <?php 
        if($wp_query->queried_object->parent){
            echo get_term_parents($wp_query->queried_object->parent,'categoria',true,'-',false);   
        }
        ?>
    </nav>
    
    <h1><?php single_cat_title()?></h1>
    
    <?php 
    $catatual = get_term_by('slug','acessorios','categoria');
    $args = array(
        'type'                     => 'post',
        'child_of'                 => $catatual->term_id,
        'parent'                   => '',
        'orderby'                  => 'name',
        'order'                    => 'ASC',
        'hide_empty'               => 0,
        'hierarchical'             => true,
        'exclude'                  => '',
        'include'                  => '',
        'number'                   => NULL,
        'taxonomy'                 => 'categoria',
        'pad_counts'               => false );
    ?>
    <ul class="lista horizontal">
    
        <?php $categories = get_categories($args); $cont = 0;
          foreach ($categories as $category) { $cont++;?>
        <li <?php if($cont == 4){echo 'class="last"'; $cont = 0;}?>>
            <a title="<?php echo $category->cat_name; ?>" href="<?php url_site('categoria/'.$category->category_nicename)?>">
                <img src="<?php url_tema('img/cat-'.$category->category_nicename.'.jpg')?>">
            </a>                
            <a href="<?php url_site('categoria/'.$category->category_nicename)?>"><?php echo $category->cat_name; ?></a>
            <p><?php echo $category->category_description;?></p>
        </li>
        <?php } ?>
        
    </ul>
    
<?php get_footer(); ?>