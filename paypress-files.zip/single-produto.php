<?php
/**
 * @package WordPress
 * @subpackage Ecommerce
 */

get_header(); 

	if(have_posts()): while(have_posts()): the_post(); global $id_anterior; $id_anterior = $post->ID; ?>
        <nav id="breadcrumbs">
            <a href="<?php url_site()?>" title="<?php trans('Back to Home page','Voltar para a página inicial')?>">Home</a> 
            &nbsp;<img src="<?php url_tema('img/seta.png')?>">&nbsp;			
			<?php 
            $raw = get_the_terms($post->ID,'categoria');
            foreach($raw as $cat){
				if($cat->parent){
					echo get_term_parents($cat->parent,'categoria',true,'-',false,'  ').'<a href="'.get_bloginfo('url').'/categoria/'.$cat->slug.'">'.$cat->name.'</a>';
				}else{
					echo '<a href="'.get_bloginfo('url').'/categoria/'.$cat->slug.'">'.$cat->name.'</a><';
				}
            }
            ?>
            &nbsp;<img src="<?php url_tema('img/seta.png')?>">&nbsp; <?php the_title()?>
        </nav>
			
        <h1><?php the_title()?></h1>
        
        <div id="produto-img">
			<?php if(has_post_thumbnail()){ 
                $idattach = get_post_thumbnail_id($post->ID);
                $full = wp_get_attachment_image_src($idattach,'full');
                $large = wp_get_attachment_image_src($idattach,'large');
				$thumb = wp_get_attachment_image_src($idattach,'thumbnail');
				
                ?>
                <a rel="lightbox[single]" title="<?php the_title()?>" href="<?php echo $full[0];?>">
                    <img src="<?php echo $large[0];?>">
                </a>
            <?php } ?>
            <ul id="thumbnails">
            	<li>
                	<a href="<?php echo $large[0];?>" title="<?php echo $full[0];?>">
                        <img src="<?php echo $thumb[0];?>">
                    </a>
                </li>
				<?php
                for ($x=2; $x<=5; $x++){
                    if (MultiPostThumbnails::has_post_thumbnail('produto','imagem'.$x,$post->ID)){											
                        $idattach = MultiPostThumbnails::get_post_thumbnail_id('produto','imagem'.$x,$post->ID);
                        $largeT = wp_get_attachment_image_src($idattach,'large');
                        $fullT = wp_get_attachment_image_src($idattach,'full');
                        $attachdata = get_post($idattach);
                        $attachname = get_post_meta($idattach, '_wp_attached_file',true);
                        
                        if($x==5){$last = 'class="last"';}
                        echo '<li '.$last.'><a href="'.$largeT[0].'" title="'.$fullT[0].'">';
                        MultiPostThumbnails::the_post_thumbnail('produto', 'imagem'.$x,$post->ID, 'thumbnail'); 
                        echo '</a></li>';
                    };
                }
                ?>
            </ul>
		</div><!-- end produto-img -->
        
        <div id="produto-acoes">
        
			<?php 
			$pr_cores = get_post_meta($post->ID, 'pr_cores',TRUE); 
			
            $valoranteriorRAW = get_post_meta($post->ID, 'pr_valoranterior',true);
			$valoranterior = number_format($valoranteriorRAW, 2, ',', '.');
            $valorRAW = get_post_meta($post->ID, 'pr_valor',true);
			$valor = number_format($valorRAW, 2, ',', '.');
			
			$indisponivel = get_post_meta($post->ID, 'pr_indisponivel', TRUE);
			$promocao = get_post_meta($post->ID, 'pr_promocao', TRUE);
			
			$peso = get_post_meta($post->ID, 'pr_peso',true);
			
			$embrapa = get_post_meta($post->ID, 'pr_embrapa', TRUE);
			$ibd = get_post_meta($post->ID, 'pr_ibd', TRUE);
			
			$posicaodavirgula = strpos($valor,",");
			$antesdavirgula = substr($valor,0,$posicaodavirgula+1);
			$depoisdavirgula = substr($valor,$posicaodavirgula+1);
			
			$parcela = $valorRAW / 18;
			
			$parcela = number_format($parcela, 2, ',', '.');
			
            if($promocao == '1' && !empty($valoranterior) && !empty($valor)){?>
            	<span class="valor-antigo"><?php trans('From','De')?> R$ <?php echo $valoranterior;?></span>
            	<span class="valor-atual"><?php trans('To','Por')?> R$ <b><?php echo $antesdavirgula;?></b><sup><?php echo $depoisdavirgula;?></sup> <?php if(is_en()){?><a title="All store prices are in Brazilian Real (BRL)" class="brlwarning">*</a><?php }?></span>
            <?php }else{ ?>
            	<span class="valor-atual">R$ <b><?php echo $antesdavirgula;?></b><sup><?php echo $depoisdavirgula;?></sup> <?php if(is_en()){?><a title="All store prices are in Brazilian Real (BRL)" class="brlwarning">*</a><?php }?></span>
            <?php }?>
			
		    <div id="parcelamento">
				<?php trans('finance in <b>18x</b> of','em até <b>18x</b> de')?> <b>R$ <?php echo $parcela;?></b> <?php trans('on credit card','no cartão de crédito')?><br>
				<a id="formas" class="down"><?php trans('discover our payment methods','conheça as nossas formas de pagamento')?></a>
				<div style="display:none">
					<p><img src="<?php url_tema('img/paypal.png')?>"></p>
					<p><img src="<?php url_tema('img/pagseguro.png')?>"></p>
				</div>
			</div>
            
            <?php 
			if(!empty($pr_cores) && is_array($pr_cores)){
				
				$source = $pr_cores;
				
				/* CORES **************************/
				$cores = array();
				//printr($pr_cores);
				foreach($source as $item){
					if((int)$item['quantidade'] > 0){
						if(is_en()){$cor = trim($item['cor_en']);}else{$cor = trim($item['cor']);}
						$hexa = $item['hexa'];
						if(!isset($cores[$cor])){
							$cores[$cor] = $hexa;
						}
					}
				}
				
				/* TAMANHOS **************************/
				$tamanhos = array();
				foreach($source as $item){
					if((int)$item['quantidade'] > 0){
						if(is_en()){
							$cor = trim($item['cor_en']);
							$tamanho = $item['tamanho_en'];
							$tamanho_nome = $item['tamanho_nome_en'];
						}else{
							$cor = trim($item['cor']);
							$tamanho = $item['tamanho'];
							$tamanho_nome = $item['tamanho_nome'];
						}
						
						$qtd = $item['quantidade'];
						$rand = $item['rand'];
						if(!isset($tamanhos[$cor])){
							$tamanhos[$cor] = array();
						}
						$tamanhos[$cor][$tamanho]['quantidade'] = $qtd;
						$tamanhos[$cor][$tamanho]['rand'] = $rand;
						$tamanhos[$cor][$tamanho]['tamanho_nome'] = $tamanho_nome;
					}
				}
			}
			
			
			
			if(!$indisponivel && count($tamanhos)){
				
				if(count($cores)){
					echo '<p>'.trans('Available colours','Disponível nas cores',false).'</p>';
					echo '<ul id="cores-disponiveis">';
					foreach($cores as $cor => $hexa){
						echo '<li><a title="'.$cor.'" data-nomecor="'.$cor.'" data-cor="'.sanitize_title($cor).'" style="background-color:'.$hexa.'"></a></li>';
						}
					echo '</ul>';
				}

				if(count($tamanhos)){
					echo '<p>'.trans('Available sizes','Disponível nos tamanhos',false).'</p>';
					echo '<div id="tamanhos-disponiveis">';
					$x = 0;
					foreach($tamanhos as $cor => $item){
						if($x != 0){ $fechado = 'fechado';}
						echo '<ul id="'.sanitize_title($cor).'" class="'.$fechado.'">';
						foreach($item as $tamanho => $dados){
							$qntd = $dados['quantidade'];
							$rand = $dados['rand'];
							$tamanho_nome = $dados['tamanho_nome'];
							if($qntd > 0){
								echo '<li><a title="'.$tamanho_nome.'" data-tamanho="'.$tamanho.'" data-qntdmax="'.$qntd.'" data-rand="'.$rand.'">'.$tamanho.'</a></li>';
							}
						}
						echo '</ul>';
						$x++;
					}
					echo '</div>';
				}
				?>
				<form id="pr-form" name="pr-form" method="post" action="">            
					<input type="hidden" name="page" value="<?php echo $post->ID; ?>"/>
					<input type="hidden" name="pr-id" id="pr-id" value="<?php echo $post->ID; ?>" />
					<input type="hidden" name="pr-nome" id="pr-nome" value="<?php echo $post->post_title; ?>" />
					<input type="hidden" name="pr-tamanho" id="pr-tamanho" value="" />
					<input type="hidden" name="pr-cor" id="pr-cor" value="" />
					<input type="hidden" name="pr-quantidade" id="pr-quantidade" value="1" />
					<input type="hidden" name="pr-qntdmax" id="pr-qntdmax" value="" />
					<input type="hidden" name="pr-rand" id="pr-rand" value="" />
					<input type="hidden" name="pr-peso" id="pr-peso" value="<?php echo $peso; ?>" />
					<input type="hidden" name="pr-valor" id="pr-valor" value="<?php echo $valorRAW; ?>" />                
					<?php wp_nonce_field('produto-nonce','incrementar-produto'); ?>
					<input type="hidden" name="lang" value="<?php echo qtrans_getLanguage();?>"/>
					<input type="image" src="<?php url_tema(trans('img/comprar-en.png','img/comprar.png',false))?>" alt="<?php trans('add to cart','adicionar ao carrinho')?>">
				</form>
            <?php }else{?>
				<p><?php trans('Product <b>unavailable at this moment</b> but we will manufacturing it soon!','Produto <b>indisponível no momento</b>, mas iremos produzi-lo em breve!')?></p>
				<p><?php trans('<b>Express your interest</b> in this product:','<b>Manifeste o seu interesse</b> neste produto:')?></p>
				<a id="tenho-interesse"><img src="<?php url_tema(trans('img/tenho-interesse-en.png','img/tenho-interesse.png',false))?>"></a>
				
				<form id="interesse" method="post" action="" style="display:none">
					<input type="hidden" name="interesse-id" id="interesse-id" value="<?php echo $post->ID; ?>" />	
					<a class="email-sugestao"></a>
					<input type="email" id="interesse-email" name="interesse-email" value="<?php trans('Type here your e-mail','Digite aqui o seu e-mail');?>"
					onBlur="if(this.value=='')this.value='<?php trans('Type here your e-mail','Digite aqui o seu e-mail')?>';" 
					onFocus="if(this.value=='<?php trans('Type here your e-mail','Digite aqui o seu e-mail')?>')this.value='';" 
					maxlength="249" required="required">
					<?php wp_nonce_field('produto-nonce','tenho-interesse'); ?>	
					<input type="image" src="<?php url_tema(trans('img/avisar-en.png','img/avisar.png',false))?>">
					<div class="finalizar-erros"></div>
				</form>
				
			<?php }?>
			
			<?php if($embrapa){?>
				<div class="selos">
					<img src="<?php url_tema('img/embrapa.png')?>">
					<?php trans('This product was made with naturally colored cotton and is ','Este produto foi feito com algodão naturalmente colorido e')?> 
					<a target="_blank" href="http://www.cnpa.embrapa.br/index.html">
						<?php trans('Embrapa certified','certificado pela Embrapa')?>.
					</a>
				</div>
			<?php }?>
			<?php if($ibd){?>
				<div class="selos">
					<img src="<?php url_tema('img/ibd.png')?>">
					<?php trans('This product has the','Este produto possui a')?> 
					<a target="_blank" href="<?php trans('http://www.ibd.com.br/Certificacao_DefaultEng.aspx?categoria=ORGANI&ling=INGLE','http://www.ibd.com.br/Certificacao_Default.aspx?categoria=ORGAN&ling=PORTU')?>">
						<?php trans('IBD Organic Certification','certificação IBD Orgânico')?>.
					</a>
				</div>
			<?php }?>
				
			<p><?php trans('Share this product','Compartilhe este produto')?></p>
			
			<div class="botoes-sociais">

				<a name="fb_share" type="button" share_url="<?php the_permalink()?>">Compartilhar</a>
				<script src="http://static.ak.fbcdn.net/connect.php/js/FB.Share" type="text/javascript"></script>				
				
				<a href="https://twitter.com/share" class="twitter-share-button"
				data-url="<?php url_site()?>?p=<?php the_ID()?>" 
				data-via="artbrasilis" 
				data-text="<?php the_title()?>" 
				data-count="horizontal" 
				data-lang="en">Tweet</a>
				<div class="g-plus" data-action="share" data-annotation="bubble"></div>
			</div>			
                            
        </div><!-- end produto-acoes -->
        
        <div id="produto-desc">
            <h2><?php trans('About the product','Sobre o produto')?></h2>
            <?php the_content()?>
            
            <hr class="hr610">
            
            <h2><?php trans('Like this product? Leave your comment!','Gostou? Comente este produto!')?></h2>
            
            <?php comments_template( ); ?>    
    	</div><!-- end produto-desc -->

    <?php endwhile; endif;?>
                
        <div id="sidebar">
			
            <hr class="hr300">
        
            <h3><?php trans('Other similar products','Outros produtos da mesma linha')?></h3>
            
            <?php
            $produtos = new WP_Query(array('post_type'=> 'produto','posts_per_page' => '2','post__not_in' => array($id_anterior))); 
            if($produtos->have_posts()): ?>
            <ul id="outros-produtos" class="lista vertical">
            
                <?php while($produtos->have_posts()): $produtos->the_post();?>
                <li>
                    <?php if(has_post_thumbnail()){ 
                    $idattach = get_post_thumbnail_id($post->ID);
                    $full = wp_get_attachment_image_src($idattach,'full');
                    $medio = wp_get_attachment_image_src($idattach,'medio');
					$novidade = get_post_meta($post->ID, 'pr_novidade', TRUE);
                    ?>
                        <a title="<?php the_title()?>" href="<?php the_permalink()?>">
                            <img src="<?php echo $medio[0];?>">
							<?php if($novidade){?>
								<img class="novidade" src="<?php url_tema(trans('img/novidade-en.png','img/novidade.png',false))?>">
							<?php }?>
                        </a>
                    <?php } ?>
                    
                    <a href="<?php the_permalink()?>"><?php the_title()?></a>
                    <p><?php if(is_en()){echo get_post_meta($post->ID, 'en_resumo', TRUE);}else{echo get_post_meta($post->ID, 'pt_resumo', TRUE);}?></p>
                </li>
                <?php endwhile; ?>
                
            </ul>
            <?php endif;?>
        </div>
 
<script src="<?php url_fresh('js/libs/wTooltip.1.7.min.js')?>"></script>
<script src="<?php url_fresh('js/libs/jquery.tools.min.js')?>"></script>
<script src="<?php url_fresh('js/libs/jquery.mailcheck.min.js')?>"></script>
<script type="text/javascript">
	(function($){
		$(document).ready(function(){
			
			$("#pr-form").submit(function(e){
				var tamanho = $("#pr-tamanho").val(); 
				var cor = $("#pr-cor").val();
				if(cor === ""){
					alert('<?php trans('You must choose a color first','Você deve escolher uma cor!')?>');
					e.preventDefault();
				}
				else if(tamanho === ""){
					alert('<?php trans('You must choose a size','Você deve escolher um tamanho!')?>');
					 e.preventDefault();				
				}
				else {
					//return true;
					$(this).submit();
				}
			});
			
			$(".brlwarning").wTooltip({
				position: "mouse",
				timeToStop: 2000,
				color: "red",
				opacity: 1
			});
			
			$("#cores-disponiveis li a").wTooltip({
				position: "mouse",
				timeToStop: 2000,
				color: "green",
				opacity: 1
			});
			
			$("#tamanhos-disponiveis li a").wTooltip({
				position: "mouse",
				timeToStop: 2000,
				color: "green",
				opacity: 1
			});
			
			$("#formas").on('click',function(){
				if($("#parcelamento div").is(':visible')){
					$("#parcelamento div").hide("slow");
					$(this).removeClass("up");
					$(this).addClass("down");
				}else{
					$("#parcelamento div").show("slow");
					$(this).removeClass("down");
					$(this).addClass("up");
				}
			});
			
			$("#tenho-interesse").on('click',function(){
				$("#interesse").fadeToggle("slow");
			});
	
			$('#interesse-email').on('blur', function() {
				$(this).mailcheck({
					//domains: domains,   // optional
					suggested: function(element, suggestion) {
						$('.email-sugestao').html('<?php trans('Did you mean','Você quis dizer')?> <i>' + suggestion.full + "</i> ?");
						$('.email-sugestao').fadeIn("slow");					
					},
					empty: function(element) {
					  $('.email-sugestao').fadeOut();
					}
				});
			});
			
			$('.email-sugestao').on('click', function() {
				$("#interesse-email").val($(this).find('i').html());
				$('.email-sugestao').fadeOut();
			});
			
			$.tools.validator.localize("pt", {
				'*'				: 'Por favor, corrija os dados deste campo',
				':email'  		: 'Por favor, entre com um e-mail válido',
				':number' 		: 'Por favor, digite um valor numérico',
				//':radio' 		: 'Por favor, escolha uma forma de pagamento',
				'[max]'	 		: 'Por favor, entre com um valor menor que $1',
				'[min]'	 		: 'Por favor, entre com um valor maior que $1',
				'[required]' 	: 'Por favor, este campo é obrigatório'
			});
		
			$("#interesse").validator({lang: 'pt'});
			
		});
	})(window.jQuery);
</script>   
<?php get_footer() ?>