<?php
/**
 * @package WordPress
 * @subpackage Ecommerce
 */

get_header(); 

if(have_posts()): while(have_posts()): the_post();?>

<nav id="breadcrumbs">
	<a href="<?php url_site()?>" title="<?php trans('Back to Home page','Voltar para a página inicial')?>">Home</a>
	&nbsp;<img src="<?php url_tema('img/seta.png')?>">&nbsp;
	<a href="<?php url_site('carrinho')?>"><?php trans('Shopping Cart','Carrinho')?></a>
</nav>
	
<h1><?php the_title()?></h1>

<?php endwhile; endif;?>
   
<article id="page">
<?php 
global $logado;
$logado = false;
$cep = $_SESSION['cep'];

//echo "<pre>"; print_r($cep); echo "</pre>"; 

if(is_user_logged_in()){$logado = true; global $current_user; get_currentuserinfo(); }

if(isset($cep['frete-escolhido'])){?>

	<h6>
	<?php if($logado){echo 'Você já é um usuário registrado, confira abaixo os dados de entrega e escolha o método de pagamento:';
	}else{
		echo 'Preencha abaixo seus dados para entrega e escolha o método de pagamento.<br> Caso você já possua cadastro conosco, por favor, faça o ';
	?>
		<a href="<?php url_site('login')?>/?ref=finalizar">login aqui.</a>
	<?php
	}?>		
	</h6>
		
	<form action="" method="post" name="checkout" id="checkout">
	<input type="hidden" name="page" value="<?php echo $post->ID; ?>"/>
	<?php wp_nonce_field('produto-nonce','checkout'); ?>
	<input type="hidden" name="ip" value="<?php echo get_client_ip();?>"/>
	<input type="hidden" name="lang" value="<?php echo qtrans_getLanguage();?>"/>
	<table width="900">
	<tr>
	<td width="450">
		<label for="nome">Nome completo / Razão social</label>
		<input tabindex="1" type="text" name="nome" id="nome" value="<?php echo get_user_meta($current_user->ID,'nome',true)?>" maxlength="249" required="required">
		
		<label for="cpf_cnpj">CPF / CNPJ <small class="preto">(Necessário para Nota fiscal)</small></label>
		<input tabindex="1" type="text" name="cpf_cnpj" id="cpf_cnpj" value="<?php echo get_user_meta($current_user->ID,'cpf_cnpj',true)?>" maxlength="14" required="required">
			
		<?php if($logado){ $email = get_user_meta($current_user->ID,'email',true); if(empty($email)){ $email = $current_user->user_email;}?>
			<label for="email">E-mail 
				<a class="outro-email" href="<?php echo wp_logout_url(get_bloginfo('url').'/finalizar-compra/'); ?>">Usar outro e-mail</a>
			</label>
			<input tabindex="2" type="text" id="email" value="<?php echo $email?>" disabled="disabled">
			<input type="hidden" name="email" value="<?php echo $email;?>">
		<?php }else{?> 
			<label for="email">E-mail 
				<a class="email-sugestao"></a>
			</label>
			<input tabindex="2" type="email" name="email" id="email" value="" maxlength="99" required="required">
		<?php }?> 
		
		<?php if($cep['frete'] == 'brasil'){?>
			<label for="ddd">DDD</label>
			<input tabindex="3" type="text" name="ddd" id="ddd" value="<?php echo get_user_meta($current_user->ID,'ddd',true)?>" maxlength="2" required="required">
		<?php }?>
		
		<label for="telefone">Telefone para contato</label>
		<input tabindex="4" type="text" name="telefone" id="telefone" value="<?php echo get_user_meta($current_user->ID,'telefone',true)?>" required="required">
		
		<?php if(!$logado){?>
		<label for="senha">Escolha uma senha</label>
		<input tabindex="5" type="password" name="senha" id="senha" value="" maxlength="32" required="required">
		
		<label for="repsenha">Repita a senha</label>
		<input tabindex="6" type="password" name="repsenha" id="repsenha" value="" maxlength="32" required="required">
		
		<label for="newsletter">
			<input tabindex="7" type="checkbox" id="newsletter" name="newsletter" value="sim" <?php checked($_POST['newsletter'], 'sim' ); ?>>
			<small>Desejo receber novidades e informações da Ecommerce por e-mail.</small>
		</label>
		<?php }?>
		
		<p><br>Escolha abaixo o método de pagamento:</p>
		
		<?php if($cep['frete'] == 'brasil'){?>
			<label for="pagseguro">
				<input tabindex="9" type="radio" id="pagseguro" name="forma_pagamento" value="pagseguro" required="required" data-message="Por favor, escolha uma forma de pagamento">
				<img src="<?php url_tema('img/badge-pagseguro.png')?>">
			</label>		
			<p><br></p>
		<?php }?>
		<label for="paypal">
			<input tabindex="8" type="radio" id="paypal" name="forma_pagamento" value="paypal" required="required" data-message="Por favor, escolha uma forma de pagamento">
			<img src="<?php url_tema('img/badge-paypal.png')?>">
		</label>
		
	</td>
	<td>		
		<label for="endereco">Endereço</label>
		<input tabindex="10" type="text" name="endereco" id="endereco" value="<?php echo get_user_meta($current_user->ID,'endereco',true)?>" maxlength="249" required="required">
		
		<label for="numero">Número</label>
		<input tabindex="11" type="text" name="numero" id="numero" value="<?php echo get_user_meta($current_user->ID,'numero',true)?>" maxlength="249" required="required">
		
		<label for="complemento">Complemento</label>
		<input tabindex="12" type="text" name="complemento" id="complemento" value="<?php echo get_user_meta($current_user->ID,'complemento',true)?>" maxlength="249" required="required">
		
		<label for="bairro">Bairro</label>
		<input tabindex="13" type="text" name="bairro" id="bairro" value="<?php echo get_user_meta($current_user->ID,'bairro',true)?>" maxlength="249" required="required">
		
		<?php if($cep['frete'] == 'brasil'){?>
			<label for="cep">CEP</label>
			<input tabindex="14" type="text" id="cep" value="<?php echo $cep['cep']?>" maxlength="9" disabled="disabled">
			<input type="hidden" name="cep" value="<?php echo $cep['cep']?>">
		<?php }else{ ?>
			<label for="cep">CEP</label>
			<input tabindex="14" type="text" id="cep" name="cep" value="<?php echo $cep['cep']?>" maxlength="200" required="required">
		<?php }?>
		
		<?php if($cep['frete'] == 'brasil'){?>
		
			<label for="estado">Estado</label>
			<select tabindex="15" name="estado" id="estado" value="<?php echo get_user_meta($current_user->ID,'estado',true)?>" required="required"></select>
	
			<label for="cidade">Cidade<a tabindex="16" class="outra_cidade down">Não achou sua cidade?</a></label>
			<?php 
				$cidade = get_user_meta($current_user->ID,'cidade',true);
				$outra_cidade = get_user_meta($current_user->ID,'outra_cidade',true);
				if(!empty($cidade) || !$logado){
			?>
				<select tabindex="17" name="cidade" id="cidade" value="<?php echo $cidade;?>" required="required"></select>
				<input tabindex="18" type="text" name="outra_cidade" id="outra_cidade" value="<?php trans('Type here your city','Digite aqui o nome da sua cidade');?>" disabled="disabled" style="display:none"
				onBlur="if(this.value=='')this.value='Digite aqui o nome da sua cidade';" 
				onFocus="if(this.value=='Digite aqui o nome da sua cidade')this.value='';" 
				maxlength="249" required="required">
			<?php }else{?>
				<select tabindex="17" name="cidade" id="cidade" disabled="disabled" style="display:none"  required="required"></select>
				<input tabindex="18" type="text" name="outra_cidade" id="outra_cidade" value="<?php echo $outra_cidade;?>" 
				onBlur="if(this.value=='')this.value='Digite aqui o nome da sua cidade';" 
				onFocus="if(this.value=='Digite aqui o nome da sua cidade')this.value='';" 
				maxlength="249" required="required">
			<?php }?>
		<?php }else{ //frete exterior?>
			<label for="estado">Estado</label>
			<input tabindex="15" type="text" name="estado" id="estado" value="<?php echo get_user_meta($current_user->ID,'estado',true)?>" maxlength="249" required="required">
			
			<label for="outra_cidade">Cidade</label>
			<input tabindex="16" type="text" name="outra_cidade" id="outra_cidade" value="<?php echo get_user_meta($current_user->ID,'outra_cidade',true)?>" maxlength="249" required="required">
		<?php }?>
		
		<label for="pais">País</label>
		<?php if($cep['frete'] == 'brasil'){?>
			<input tabindex="19" type="text" id="pais" name="pais_nome" value="Brasil" disabled="disabled">
			<input type="hidden" name="pais" value="BR">	
		<?php }else{?>
			<input tabindex="19" type="text" id="pais" name="pais_nome" value="<?php echo $cep['pais_nome']?>" disabled="disabled">
			<input type="hidden" name="pais" value="<?php echo $cep['pais']?>">	
		<?php }?>
				
		<input id="pagar" tabindex="20" type="image" src="<?php url_tema('img/realizar-pagamento.png')?>">
	</td>
	</tr>
	<tr><td colspan="2">&nbsp;</td></tr>
	<tr>
		<td colspan="2" style="vertical-align:middle"><a href="<?php url_site('carrinho')?>" class="continuar-comprando"><img src="<?php url_tema('img/seta-grande-esquerda.png')?>"> oltar para o carrinho</a></td>
	</tr>
	</table>
	</form>

<?php }else{ ?>

	<h6>Você não pode acessar esta página diretamente!</h6>
	
	<hr class="hr940">
		
	<h6>Conheça os produtos da Ecommerce</h6>
	
	<?php
	$cont = 0;
	$produtos = new WP_Query(array('posts_per_page' => '-1','post_type'=> 'produto','meta_key'=> 'destaque', 'meta_value'=>'on')); 
	if($produtos->have_posts()): ?>
	<ul class="lista horizontal">
	
		<?php while($produtos->have_posts()): $produtos->the_post(); $cont++; ?>
		<li <?php if($cont == 4){echo 'class="last"'; $cont = 0;}?>>
			<?php if(has_post_thumbnail()){ 
			$idattach = get_post_thumbnail_id($post->ID);
			$full = wp_get_attachment_image_src($idattach,'full');
			$medio = wp_get_attachment_image_src($idattach,'medio');
			$novidade = get_post_meta($post->ID, 'pr_novidade', TRUE);
			?>
				<a title="<?php the_title()?>" href="<?php the_permalink()?>">
					<img src="<?php echo $medio[0];?>">
					<?php if($novidade){?>
						<img class="novidade" src="<?php url_tema('img/novidade.png')?>">
					<?php }?>
				</a>
			<?php } ?>
			
			<a href="<?php the_permalink()?>"><?php the_title()?></a>
			<p><?php echo get_post_meta($post->ID, 'pt_resumo', TRUE);?></p>
		</li>
		<?php endwhile; ?>
		
	</ul>
	<?php endif;?>	
	
<?php }?>

</article>

<script src="<?php url_fresh('js/libs/jquery.mailcheck.min.js')?>"></script>
<script src="<?php url_fresh('js/libs/cidades-estados-1.2-utf8.js')?>"></script>
<script src="<?php url_fresh('js/libs/jquery.tools.min.js')?>"></script>
<script type="text/javascript">
(function($){
	$(document).ready(function(){
		
		<?php if($cep['frete'] == 'brasil'){?>
		new dgCidadesEstados({
			estado: $('#estado').get(0),
			cidade: $('#cidade').get(0)
		});
		<?php } ?>
		
		$.tools.validator.localize("pt", {
			'*'				: 'Por favor, corrija os dados deste campo',
			':email'  		: 'Por favor, entre com um e-mail válido',
			':number' 		: 'Por favor, digite um valor numérico',
			//':radio' 		: 'Por favor, escolha uma forma de pagamento',
			'[max]'	 		: 'Por favor, entre com um valor menor que $1',
			'[min]'	 		: 'Por favor, entre com um valor maior que $1',
			'[required]' 	: 'Por favor, este campo é obrigatório'
		});
	
		$("#checkout").validator({lang: 'pt'}).submit(
			function(e){
				if (!e.isDefaultPrevented()) {
					$("#pagar").prop("disabled",true);
					e.submit();
					setTimeout(function() {
						$("#pagar").prop("disabled",false);
					}, 5000);
				}
				e.preventDefault();		
		});
		
			
		$.tools.validator.fn("#repsenha",
			function(el, value){
				return (value == $('#senha').val()) ? true : false;
			}
		);
				
		<?php if($cep['frete'] == 'brasil'){?>
		
		$.tools.validator.fn("#outra_cidade",
			function(el, value){
					if(value == 'Digite aqui o nome da sua cidade' || value == 'Type here your city'){ return false;}else{ return true; }
			}
		);
		
		$("#telefone").mask("9999-9999");
		<?php } ?>
		
		//var domains = ['yahoo.com.br'];
		$('#email').on('blur', function() {
			$(this).mailcheck({
				//domains: domains,   // optional
				suggested: function(element, suggestion) {
					$('.email-sugestao').html('Você quis dizer <i>' + suggestion.full + "</i> ?");
					$('.email-sugestao').fadeIn("slow");					
				},
				empty: function(element) {
				  $('.email-sugestao').fadeOut();
				}
			});
		});
		
		$('.email-sugestao').on('click', function() {
			$("#email").val($(this).find('i').html());
			$('.email-sugestao').fadeOut();
		});
		
		$(".outro-email").click(function(e){
			var answer = confirm("Para usar outro e-mail você deve se deslogar, tem certeza?");
			if (!answer){
				e.preventDefault();	
		}	
	});
	});
})(window.jQuery);
</script>
<?php get_footer() ?>