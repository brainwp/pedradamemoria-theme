<?php
/**
 * @package WordPress
 * @subpackage Ecommerce
 */

get_header(); 

	if(have_posts()): while(have_posts()): the_post();?>
    
	<nav id="breadcrumbs">
		<a href="<?php url_site()?>" title="Voltar para a página inicial">Home</a>
		&nbsp;<img src="<?php url_tema('img/seta.png')?>">&nbsp;
		<?php 
		if($post->post_parent){
			$pai = get_post($post->post_parent);
			//printr($pai);
			?>
			<a href="<?php url_site($pai->post_name)?>"><?php echo $pai->post_title;?></a>
			<?php
		}
		?>
	</nav>
		
	<h1><?php the_title()?></h1>
	
<?php endwhile; endif;?>

	<div id="carrinho">
	<?php
	$cep = $_SESSION['cep'];
	
	if($_GET['frete'] == 'exterior'){
		$cep['frete'] = 'exterior';
		$_SESSION['cep'] = $cep;
	}
	if($_GET['frete'] == 'brasil'){
		$cep['frete'] = 'brasil';
		$_SESSION['cep'] = $cep;
	}
	
	//echo "<pre>"; print_r($cep); echo "</pre>"; 
		
	$produtos = $_SESSION['carrinho'];
	
	//echo "<pre>"; print_r($produtos); echo "</pre>"; 
	if(is_array($produtos)){
			
		$contador = 0;		
		$pesototal = 0;
		$valortotal = 0;			
        foreach ($produtos as $key => $item){
			$contador += $item['quantidade']; 
			$pesototal += $item['pesototal']; 
			$valortotal += $item['valortotal'];
		}
		
		//echo '<pre>'; print_r($cep); echo '</pre>';
		//echo '<pre>'; print_r($produtos); echo '</pre>';
		//echo 'peso em gramas exato: '.$pesototal.' / valor total: '.$valortotal;
        ?> 
        <table border="0" id="carrinho-table">
            <thead>
                <tr class="carrinho-titulos">
                <th colspan="2">produto</th>
                <th>cor</th>
				<th>tamanho</th>
				<th>preço</th>
				<th>quantidade</th>
                <th>valor total</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($produtos as $key => $item){ global $post; $post = get_post($item['id']);?>
                <tr>
                    <td class="carrinho-thumb">
						<?php if(has_post_thumbnail($post->ID)){ 
							$idattach = get_post_thumbnail_id($post->ID);
							$full = wp_get_attachment_image_src($idattach,'full');
							$large = wp_get_attachment_image_src($idattach,'large');
							$thumb = wp_get_attachment_image_src($idattach,'thumbnail');
							?>
							<a rel="lightbox[<?php echo $item['id']?>]" title="<?php the_title()?>" href="<?php echo $large[0];?>">
								<img src="<?php echo $thumb[0];?>">
							</a>
						<?php } ?>   
                    </td>
					<td class="carrinho-info">
						<a href="<?php the_permalink()?>"><?php the_title()?></a>
                		<p><?php if(is_en()){echo get_post_meta($post->ID, 'en_resumo', TRUE);}else{echo get_post_meta($post->ID, 'pt_resumo', TRUE);}?></p>
						<form class="carrinho-remover" method="post" action="">            
                            <input type="hidden" name="page" value="<?php echo $post->ID; ?>"/>
                            <input type="hidden" name="pr-rand" id="pr-rand" value="<?php echo $item['rand']; ?>" />
							<?php wp_nonce_field('produto-nonce','remover-produto'); ?>
							<a><b>remover produto</b></a>
                        </form>						
					</td>
					<td class="carrinho-cor"><?php echo $item['cor']?></td>
					<td class="carrinho-tamanho"><?php echo $item['tamanho']?></td>
					<td class="carrinho-preco">R$ <?php echo number_format($item['valor'], 2, ',', '.');?></td>
                    <td class="carrinho-quantidade">
                        <form method="post" action="">            
                            <input type="hidden" name="page" value="<?php echo $post->ID; ?>"/>
                            <input type="hidden" name="pr-id" id="pr-id" value="<?php echo $item['id']; ?>" />
                            <input type="hidden" name="pr-nome" id="pr-nome" value="<?php echo $item['nome']; ?>" />
                            <input type="hidden" name="pr-tamanho" id="pr-tamanho" value="<?php echo $item['tamanho']; ?>" />
                            <input type="hidden" name="pr-cor" id="pr-cor" value="<?php echo $item['cor']; ?>" />
                            <input type="hidden" name="pr-quantidade" id="pr-quantidade" value="<?php echo $item['quantidade']; ?>" />
							<input type="hidden" name="pr-qntdmax" id="pr-qntdmax" value="<?php echo $item['qntdmax']; ?>" />
							<input type="hidden" name="pr-rand" id="pr-rand" value="<?php echo $item['rand']; ?>" />
							<input type="hidden" name="pr-valor" id="pr-valor" value="<?php echo $item['valor']; ?>" />
                            <input type="hidden" name="pr-peso" id="pr-peso" value="<?php echo $item['peso']; ?>" />
							<?php wp_nonce_field('produto-nonce','subtrair-produto'); ?>
                            <input type="image" src="<?php url_tema('img/carrinho_subtrair.png')?>" class="icone-submit" />
                        </form>
                        <span><?php echo $item['quantidade']?></span>
                        <form method="post" action="">            
                            <input type="hidden" name="page" value="<?php echo $post->ID; ?>"/>
                            <input type="hidden" name="pr-id" id="pr-id" value="<?php echo $item['id']; ?>" />
                            <input type="hidden" name="pr-nome" id="pr-nome" value="<?php echo $item['nome']; ?>" />
                            <input type="hidden" name="pr-tamanho" id="pr-tamanho" value="<?php echo $item['tamanho']; ?>" />
                            <input type="hidden" name="pr-cor" id="pr-cor" value="<?php echo $item['cor']; ?>" />
							<input type="hidden" name="pr-quantidade" id="pr-quantidade" value="<?php echo $item['quantidade']; ?>" />
							<input type="hidden" name="pr-qntdmax" id="pr-qntdmax" value="<?php echo $item['qntdmax']; ?>" />
							<input type="hidden" name="pr-rand" id="pr-rand" value="<?php echo $item['rand']; ?>" />
                            <input type="hidden" name="pr-valor" id="pr-valor" value="<?php echo $item['valor']; ?>" />
                            <input type="hidden" name="pr-peso" id="pr-peso" value="<?php echo $item['peso']; ?>" />
                            <?php wp_nonce_field('produto-nonce','incrementar-produto'); ?>
							<input type="image" src="<?php url_tema('img/carrinho_adicionar.png')?>" class="icone-submit"  />
                        </form>                    
                    </td>
                    <td class="carrinho-total"><b>R$ <?php echo number_format($item['valortotal'], 2, ',', '.');?></b></td>
                </tr>
				<tr><td colspan="7"><hr class="hr940-table"></td></tr>
                <?php } //end for ?>
            </tbody>
            <tfoot>
	            <tr>
                    <td colspan="2" class="consulta-cep">
						<?php if($cep['frete'] != 'exterior'){?>
							<div id="frete-brasil">
								<p>por favor, informe abaixo seu CEP:</p>
								<form method="post" action="">
									<input type="text" name="pr-cep" id="pr-cep" size="8" maxlength="9" value="<?php echo $cep['cep']?>"  
									onBlur="if(this.value=='')this.value='<?php echo $cep['cep']?>';"
									onFocus="if(this.value=='<?php echo $cep['cep']?>')this.value='';"
									/>
									<input type="image" src="<?php url_tema('img/calcular-frete.png');?>">  
									<input type="hidden" name="page" value="<?php echo $post->ID; ?>"/>
									<?php wp_nonce_field('produto-nonce','consultar-cep'); ?>
								</form>	
							</div>
							<a href="<?php url_site('carrinho/?frete=exterior')?>">fora do Brasil?</a>
						<?php }else{?>
							<div id="frete-exterior">
								<p>escolha seu país abaixo para calcular o frete:</p>
								<form id="exterior" method="post" action="">
									<select id="pais" name="pais">
										<option value='0'>Escolha um país</option>
										<?php 
										$xml = trim(file_get_contents('http://www.correios.com.br/exportafacil/bb/consulta_pais.cfm'));
										$paises = simplexml_load_string($xml);
										$paises = $paises->relacao_pais;
										foreach($paises as $pais){
											//printr($pais);
											?>
											<option value="<?php echo $pais->codigo_pais;?>|<?php echo $pais->nome_pais;?>" <?php selected($pais->codigo_pais, $cep['pais']);?>><?php echo $pais->nome_pais;?></option>
											<?php
										}
										?>
									</select>
									<input type="image" src="<?php url_tema('img/calcular-frete.png')?>">  
									<input type="hidden" name="page" value="<?php echo $post->ID; ?>"/>
									<?php wp_nonce_field('produto-nonce','frete-exterior'); ?>
								</form>
							</div>
							<a href="<?php url_site('carrinho/?frete=brasil')?>">está no Brasil?</a>
						<?php }?>
                    </td>
                    <td colspan="3" class="consulta-cep">
                    	<?php if(isset($cep['cep']) && !$cep['erro'] && $cep['frete'] != 'exterior'){?>
							<p>escolha a forma de envio</p>
							<form id="formas-envio">
								<label for="sedex">
									<input 
										type="radio" 
										id="sedex" 
										data-frete-tipo="Sedex" 
										data-preco="<?php echo number_format($cep['Sedex'], 2, ',', '.');?>" 
										data-valor="<?php echo $cep['Sedex'];?>" 
										name="cr-forma-envio" 
										value="<?php echo str_replace('.','',$cep['Sedex']); ?>" 
									/>
								Sedex <b style="color:#154E48"><?php echo "R$ ".number_format($cep['Sedex'], 2, ',', '.');//str_replace('.',',',$cep['Sedex']); ?></b>
									<br><small>Até 3 dias úteis após a postagem.</small>
								</label>
								
								<label for="pac">
									<input 
										type="radio" 
										id="pac" 
										data-frete-tipo="PAC" 
										data-preco="<?php echo number_format($cep['PAC'], 2, ',', '.');?>" 
										data-valor="<?php echo $cep['PAC'];?>" 
										name="cr-forma-envio" 
										value="<?php echo str_replace('.','',$cep['PAC']); ?>"
									/>
								PAC <b style="color:#154E48"><?php echo "R$ ".number_format($cep['PAC'], 2, ',', '.');?></b>
									<br><small>Até 8 dias úteis após a postagem.</small>
								</label>								
							</form>
                        <?php } ?>
						<?php if($cep['erro'] == 'excedeu'){?>
							<p style="color:#ff0000;">
								Peso total dos produtos ultrapassou o máximo permitido pelos Correios de 30Kg
							</p>
						<?php }
						if($cep['frete'] == 'exterior' && (isset($cep['ems']) || isset($cep['leve'])) ){ ?>
							<p>escolha a forma de envio</p>
							<form id="formas-envio">
								<?php if(isset($cep['ems']) && (double)$cep['ems'] > 0){?>
									<label for="ems">
										<input 
											type="radio" 
											id="ems" 
											data-frete-tipo="ems" 
											data-preco="<?php echo number_format((double)$cep['ems'], 2, ',', '.');?>" 
											data-valor="<?php echo $cep['ems'];?>" 
											name="cr-forma-envio" 
											value="<?php echo str_replace('.','',$cep['ems']); ?>" 
										/>
									Mercadoria Expressa (EMS) <b style="color:#154E48"><?php echo "R$ ".number_format((double)$cep['ems'], 2, ',', '.');?></b>
										<br><small>Entre <?php echo $cep['prazo_ems']; ?> após a postagem.</small>
									</label>
								<?php } if(isset($cep['leve']) && (double)$cep['leve'] > 0){?>
									<label for="leve">
										<input 
											type="radio" 
											id="leve" 
											data-frete-tipo="leve" 
											data-preco="<?php echo number_format((double)$cep['leve'], 2, ',', '.');?>" 
											data-valor="<?php echo $cep['leve'];?>" 
											name="cr-forma-envio" 
											value="<?php echo str_replace('.','',$cep['leve']); ?>"
										/>
									Leve Prioritário <b style="color:#154E48"><?php echo "R$ ".number_format((double)$cep['leve'], 2, ',', '.');?></b>
										<br><small>Entre <?php echo $cep['prazo_leve']; ?> após a postagem.</small>
									</label>
								<?php } ?>			
							</form>
						<?php }	?>
                    </td>
                    <td colspan="2">
						<table id="totais">
							<tr>
								<td class="sub-titulo">Subtotal</td>
								<td class="sub-valor">R$ <span id="subtotal" data-valor="<?php echo $valortotal;?>"><?php echo number_format($valortotal, 2, ',', '.'); ?></span> <?php if(is_en()){?><a title="All store prices are in Brazilian Real (BRL)" class="brlwarning">*</a><?php }?></td>
							</tr>
							<tr>
								<td class="sub-titulo">Frete</td>
								<td class="sub-valor"><span id="total-frete" data-valor="">-</span></td>
							</tr>
							<tr>
								<td colspan="2"><hr class="hr300-table"></td>
							</tr>
							<tr id="linha-total">
								<td>TOTAL</td><td><span id="total-geral"></span></td>
							</tr>
						</table>
					</td>
                </tr>
				<tr><td colspan="7">&nbsp;</tr>
				<tr>
					<td colspan="4" style="vertical-align:middle">
					<a href="<?php url_site('descubra')?>" class="continuar-comprando"><img src="<?php url_tema('img/seta-grande-esquerda.png')?>"> Conheça os produtos da Ecommerce</a>
					</td>
					<td colspan="3">
						<form id="finalizar-compra" method="post" action="">
							<?php wp_nonce_field('produto-nonce','finalizar-carrinho'); ?>
							<input type="hidden" name="lang" value="pt"/>
							<input type="hidden" id="co-frete-tipo" name="co-frete-tipo">
							<input type="image" src="<?php url_tema('img/finalizar-compra.png')?>">
						</form>
					</td>
				</tr>
            </tfoot>
        </table>               
	<?php }else{
		echo "<p>Não há itens no seu carrinho neste momento!</p>";?>
		
		<hr class="hr940">
		
		<h6>Conheça os produtos da Ecommerce</h6>
		
		<?php
		$cont = 0;
		$produtos = new WP_Query(array('posts_per_page' => '-1','post_type'=> 'produto','meta_key'=> 'destaque', 'meta_value'=>'on')); 
		if($produtos->have_posts()): ?>
		<ul class="lista horizontal">
		
			<?php while($produtos->have_posts()): $produtos->the_post(); $cont++; ?>
			<li <?php if($cont == 4){echo 'class="last"'; $cont = 0;}?>>
				<?php if(has_post_thumbnail()){ 
				$idattach = get_post_thumbnail_id($post->ID);
				$full = wp_get_attachment_image_src($idattach,'full');
				$medio = wp_get_attachment_image_src($idattach,'medio');
				$novidade = get_post_meta($post->ID, 'pr_novidade', TRUE);
				?>
					<a title="<?php the_title()?>" href="<?php the_permalink()?>">
						<img src="<?php echo $medio[0];?>">
						<?php if($novidade){?>
							<img class="novidade" src="<?php url_tema('img/novidade.png')?>">
						<?php }?>
					</a>
				<?php } ?>
				
				<a href="<?php the_permalink()?>"><?php the_title()?></a>
				<p><?php echo get_post_meta($post->ID, 'pt_resumo', TRUE);?></p>
			</li>
			<?php endwhile; ?>
			
		</ul>
		<?php endif;?>		
	<?php } ?>
	</div>

<script src="<?php url_fresh('js/libs/wTooltip.1.7.min.js')?>"></script>
<script src="<?php url_fresh('js/libs/jquery.formatCurrency-1.4.0.min.js')?>"></script>
<script type="text/javascript">
	(function($){
		$(document).ready(function(){
			
			$(".brlwarning").wTooltip({
				position: "mouse",
				timeToStop: 2000,
				color: "red",
				opacity: 1
			});
			
			$.formatCurrency.regions['pt-BR'] = {
				symbol: 'R$',
				positiveFormat: '%s %n',
				negativeFormat: '-%s %n',
				decimalSymbol: ',',
				digitGroupSymbol: '.',
				groupDigits: true
			};
			
		});
	})(window.jQuery);
</script>       
<?php get_footer() ?>